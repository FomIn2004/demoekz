﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp2
{
    public partial class CaptchaWindow : Window
    {
        char[] azbuka = new char[] { 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', 'a', 's', 'd', 'f', 'g', 'h', 'h', 'j', 'k', 'l', 'z', 'x', 'c', 'v', 'b', 'n', 'm' };
        public CaptchaWindow()
        {
            InitializeComponent();
            captcha_txt.Text = GenerateCaptcha(azbuka, 6);
        }

        private void captcha_btn_Click(object sender, RoutedEventArgs e)
        {

            
            if(captcha.Text == captcha_txt.Text)
            {
                DataBaseWindow dbw = new DataBaseWindow();
                dbw.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Не правильно введена каптча");
                Thread.Sleep(1000);
            }
        }
        public string GenerateCaptcha(char[] azb, int length)
        {
            Random rnd = new Random();
            string result = "";
            for (int i = 0; i < length; i++)
            {
                result += azb[rnd.Next(azb.Length)];
            }
            return result;
        }
    }
}
